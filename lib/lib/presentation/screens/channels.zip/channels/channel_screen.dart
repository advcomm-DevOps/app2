// import 'package:flutter/material.dart';
// import 'package:signals/signals_flutter.dart';
// import '../../services/channel_service.dart';
// import '../../services/signal_state/channel_state.dart';
// import '../../widgets/responsive_layout.dart';
// import '../docs/doc_screen.dart';
// import '../work_area/workarea_screen.dart';
// import 'channel_list.dart';

// class ChannelScreen extends StatefulWidget {
//   const ChannelScreen({super.key});

//   @override
//   State<ChannelScreen> createState() => _ChannelScreenState();
// }

// class _ChannelScreenState extends State<ChannelScreen> {
//   // Use the public type DocScreenState
//   final GlobalKey<DocScreenState> _docScreenKey = GlobalKey();

//   @override
//   void initState() {
//     super.initState();
//     _loadChannels();
//   }

//   Future<void> _loadChannels() async {
//     await channelService.fetchChannels();
//     if (mounted &&
//         channelService.error.value == null &&
//         channelService.channels.value.isNotEmpty) {
//       channelState.selectChannelName(channelService.channels.value.first.name);
//       // channelState.selectChannelId(channelService.channels.value.first.id);
//       _docScreenKey.currentState?.loadDocumentsForChannel();
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     final showNames = channelState.showChannelNames.watch(context);
//     final isLoading = channelService.isLoading.watch(context);
//     final error = channelService.error.watch(context);
//     final channels = channelService.channels.watch(context);

//     return Scaffold(
//       body:
//           isLoading
//               ? const Center(child: CircularProgressIndicator())
//               : error != null
//               ? Center(child: Text('Error: $error'))
//               : ResponsiveLayout(
//                 channelColumn: Container(
//                   width: showNames ? 240 : 72,
//                   decoration: BoxDecoration(
//                     border: Border(
//                       right: BorderSide(color: Colors.grey.shade300),
//                     ),
//                   ),
//                   child: Column(
//                     children: [
//                       SizedBox(
//                         height: 56,
//                         child: Row(
//                           children: [
//                             if (showNames)
//                               const Padding(
//                                 padding: EdgeInsets.only(left: 16),
//                                 child: Text(
//                                   'Channels',
//                                   style: TextStyle(fontWeight: FontWeight.bold),
//                                 ),
//                               ),
//                             const Spacer(),
//                             IconButton(
//                               icon: Icon(
//                                 showNames
//                                     ? Icons.keyboard_arrow_left
//                                     : Icons.keyboard_arrow_right,
//                               ),
//                               onPressed: channelState.toggleNameVisibility,
//                               tooltip: showNames ? 'Collapse' : 'Expand',
//                             ),
//                           ],
//                         ),
//                       ),
//                       const Divider(height: 1),
//                       Expanded(
//                         child: ChannelList(
//                           channels: channels,
//                           onChannelSelected: () {
//                             _docScreenKey.currentState
//                                 ?.loadDocumentsForChannel();
//                           },
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//                 docColumn: DocScreen(key: _docScreenKey),
//                 workareaColumn: const WorkareaScreen(),
//               ),
//     );
//   }
// }
// import 'package:flutter/material.dart';
// import 'package:signals/signals_flutter.dart';
// import 'package:xdocapp/presentation/screens/user_screen/user_screen.dart';
// import '../../services/channel_service.dart';
// import '../../services/signal_state/channel_state.dart';
// import '../../widgets/responsive_layout.dart';
// import '../docs/doc_screen.dart';
// import '../work_area/workarea_screen.dart';
// import 'channel_list.dart';
// // Import the UserScreen

// class ChannelScreen extends StatefulWidget {
//   const ChannelScreen({super.key});

//   @override
//   State<ChannelScreen> createState() => _ChannelScreenState();
// }

// class _ChannelScreenState extends State<ChannelScreen> {
//   final GlobalKey<DocScreenState> _docScreenKey = GlobalKey();

//   @override
//   void initState() {
//     super.initState();
//     _loadChannels();
//   }

//   Future<void> _loadChannels() async {
//     await channelService.fetchChannels();
//     if (mounted &&
//         channelService.error.value == null &&
//         channelService.channels.value.isNotEmpty) {
//       channelState.selectChannelName(channelService.channels.value.first.name);
//       _docScreenKey.currentState?.loadDocumentsForChannel();
//     }
//   }

//   void _navigateToUserProfile() {
//     Navigator.push(
//       context,
//       MaterialPageRoute(builder: (context) => const UserScreen()),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     final showNames = channelState.showChannelNames.watch(context);
//     final isLoading = channelService.isLoading.watch(context);
//     final error = channelService.error.watch(context);
//     final channels = channelService.channels.watch(context);

//     return Scaffold(
//       body:
//           isLoading
//               ? const Center(child: CircularProgressIndicator())
//               : error != null
//               ? Center(child: Text('Error: $error'))
//               : ResponsiveLayout(
//                 channelColumn: Container(
//                   width: showNames ? 240 : 72,
//                   decoration: BoxDecoration(
//                     border: Border(
//                       right: BorderSide(color: Colors.grey.shade300),
//                     ),
//                   ),
//                   child: Column(
//                     children: [
//                       SizedBox(
//                         height: 56,
//                         child: Row(
//                           children: [
//                             // Add CircleAvatar here
//                             Padding(
//                               padding: const EdgeInsets.only(left: 8),
//                               child: GestureDetector(
//                                 onTap: _navigateToUserProfile,
//                                 child: const CircleAvatar(
//                                   radius: 20,
//                                   child: Text(
//                                     'UN',
//                                     style: TextStyle(fontSize: 16),
//                                   ),
//                                 ),
//                               ),
//                             ),
//                             if (showNames)
//                               const Padding(
//                                 padding: EdgeInsets.only(left: 8),
//                                 child: Text(
//                                   'Channels',
//                                   style: TextStyle(fontWeight: FontWeight.bold),
//                                 ),
//                               ),
//                             const Spacer(),
//                             IconButton(
//                               icon: Icon(
//                                 showNames
//                                     ? Icons.keyboard_arrow_left
//                                     : Icons.keyboard_arrow_right,
//                               ),
//                               onPressed: channelState.toggleNameVisibility,
//                               tooltip: showNames ? 'Collapse' : 'Expand',
//                             ),
//                           ],
//                         ),
//                       ),
//                       const Divider(height: 1),
//                       Expanded(
//                         child: ChannelList(
//                           channels: channels,
//                           onChannelSelected: () {
//                             _docScreenKey.currentState
//                                 ?.loadDocumentsForChannel();
//                           },
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//                 docColumn: DocScreen(key: _docScreenKey),
//                 workareaColumn: const WorkareaScreen(),
//               ),
//     );
//   }
// }
// import 'package:flutter/material.dart';
// import 'package:signals/signals_flutter.dart';
// import 'package:xdocapp/presentation/screens/user_screen/user_screen.dart';
// import '../../services/channel_service.dart';
// import '../../services/signal_state/channel_state.dart';
// import '../../widgets/responsive_layout.dart';
// import '../docs/doc_screen.dart';
// import '../work_area/workarea_screen.dart';
// import 'channel_list.dart';
// // import 'user_screen.dart';

// class ChannelScreen extends StatefulWidget {
//   const ChannelScreen({super.key});

//   @override
//   State<ChannelScreen> createState() => _ChannelScreenState();
// }

// class _ChannelScreenState extends State<ChannelScreen> {
//   final GlobalKey<DocScreenState> _docScreenKey = GlobalKey();

//   @override
//   void initState() {
//     super.initState();
//     _loadChannels();
//   }

//   Future<void> _loadChannels() async {
//     await channelService.fetchChannels();
//     if (mounted &&
//         channelService.error.value == null &&
//         channelService.channels.value.isNotEmpty) {
//       channelState.selectChannelName(channelService.channels.value.first.name);
//       _docScreenKey.currentState?.loadDocumentsForChannel();
//     }
//   }

//   void _navigateToUserProfile() {
//     Navigator.push(
//       context,
//       MaterialPageRoute(builder: (context) => const UserScreen()),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     final showNames = channelState.showChannelNames.watch(context);
//     final isLoading = channelService.isLoading.watch(context);
//     final error = channelService.error.watch(context);
//     final channels = channelService.channels.watch(context);

//     return Scaffold(
//       body:
//           isLoading
//               ? const Center(child: CircularProgressIndicator())
//               : error != null
//               ? Center(child: Text('Error: $error'))
//               : ResponsiveLayout(
//                 channelColumn: Container(
//                   width: showNames ? 240 : 72,
//                   decoration: BoxDecoration(
//                     border: Border(
//                       right: BorderSide(color: Colors.grey.shade300),
//                     ),
//                   ),
//                   child: Column(
//                     children: [
//                       SizedBox(
//                         height: 56,
//                         child: Row(
//                           crossAxisAlignment: CrossAxisAlignment.center,
//                           children: [
//                             // User avatar with name
//                             Padding(
//                               padding: const EdgeInsets.only(left: 8),
//                               child: Row(
//                                 children: [
//                                   GestureDetector(
//                                     onTap: _navigateToUserProfile,
//                                     child: const CircleAvatar(
//                                       radius: 16,
//                                       child: Text(
//                                         'UN',
//                                         style: TextStyle(fontSize: 12),
//                                       ),
//                                     ),
//                                   ),
//                                   if (showNames)
//                                     const Padding(
//                                       padding: EdgeInsets.only(left: 8),
//                                       child: Text(
//                                         'John Doe',
//                                         style: TextStyle(fontSize: 14),
//                                       ),
//                                     ),
//                                 ],
//                               ),
//                             ),
//                             const Spacer(),
//                           ],
//                         ),
//                       ),
//                       // Channels header with collapse/expand button
//                       SizedBox(
//                         height: 40,
//                         child: Row(
//                           children: [
//                             if (showNames)
//                               const Padding(
//                                 padding: EdgeInsets.only(left: 16),
//                                 child: Text(
//                                   'Channels',
//                                   style: TextStyle(
//                                     fontWeight: FontWeight.bold,
//                                     fontSize: 14,
//                                   ),
//                                 ),
//                               ),
//                             const Spacer(),
//                             IconButton(
//                               icon: Icon(
//                                 showNames
//                                     ? Icons.keyboard_arrow_left
//                                     : Icons.keyboard_arrow_right,
//                                 size: 20,
//                               ),
//                               onPressed: channelState.toggleNameVisibility,
//                               tooltip: showNames ? 'Collapse' : 'Expand',
//                               padding: EdgeInsets.zero,
//                               constraints: const BoxConstraints(),
//                             ),
//                           ],
//                         ),
//                       ),
//                       const Divider(height: 1),
//                       Expanded(
//                         child: ChannelList(
//                           channels: channels,
//                           onChannelSelected: () {
//                             _docScreenKey.currentState
//                                 ?.loadDocumentsForChannel();
//                           },
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//                 docColumn: DocScreen(key: _docScreenKey),
//                 workareaColumn: const WorkareaScreen(),
//               ),
//     );
//   }
// }
// import 'package:flutter/material.dart';
// import 'package:signals/signals_flutter.dart';
// import 'package:xdocapp/presentation/screens/user_screen/user_screen.dart';
// import '../../services/channel_service.dart';
// import '../../services/signal_state/channel_state.dart';
// import '../../widgets/responsive_layout.dart';
// import '../docs/doc_screen.dart';
// import '../work_area/workarea_screen.dart';
// import 'channel_list.dart';
// // import 'user_screen.dart';

// class ChannelScreen extends StatefulWidget {
//   const ChannelScreen({super.key});

//   @override
//   State<ChannelScreen> createState() => _ChannelScreenState();
// }

// class _ChannelScreenState extends State<ChannelScreen> {
//   final GlobalKey<DocScreenState> _docScreenKey = GlobalKey();

//   @override
//   void initState() {
//     super.initState();
//     _loadChannels();
//   }

//   Future<void> _loadChannels() async {
//     await channelService.fetchChannels();
//     if (mounted &&
//         channelService.error.value == null &&
//         channelService.channels.value.isNotEmpty) {
//       channelState.selectChannelName(channelService.channels.value.first.name);
//       _docScreenKey.currentState?.loadDocumentsForChannel();
//     }
//   }

//   void _navigateToUserProfile() {
//     Navigator.push(
//       context,
//       MaterialPageRoute(builder: (context) => const UserScreen()),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     final showNames = channelState.showChannelNames.watch(context);
//     final isLoading = channelService.isLoading.watch(context);
//     final error = channelService.error.watch(context);
//     final channels = channelService.channels.watch(context);

//     return Scaffold(
//       body:
//           isLoading
//               ? const Center(child: CircularProgressIndicator())
//               : error != null
//               ? Center(child: Text('Error: $error'))
//               : ResponsiveLayout(
//                 channelColumn: Container(
//                   width: showNames ? 240 : 72,
//                   decoration: BoxDecoration(
//                     border: Border(
//                       right: BorderSide(color: Colors.grey.shade300),
//                     ),
//                   ),
//                   child: Column(
//                     children: [
//                       // Top section with user avatar and name
//                       SizedBox(
//                         height: 56,
//                         child: Row(
//                           children: [
//                             Padding(
//                               padding: const EdgeInsets.only(left: 12),
//                               child: GestureDetector(
//                                 onTap: _navigateToUserProfile,
//                                 child: const CircleAvatar(
//                                   radius: 16,
//                                   child: Text(
//                                     'UN',
//                                     style: TextStyle(fontSize: 12),
//                                   ),
//                                 ),
//                               ),
//                             ),
//                             if (showNames)
//                               const Padding(
//                                 padding: EdgeInsets.only(left: 8),
//                                 child: Text('John Doe'),
//                               ),
//                             const Spacer(),
//                           ],
//                         ),
//                       ),
//                       // Channels header with arrow first, then text
//                       SizedBox(
//                         height: 40,
//                         child: Row(
//                           children: [
//                             IconButton(
//                               icon: Icon(
//                                 showNames
//                                     ? Icons.keyboard_arrow_left
//                                     : Icons.keyboard_arrow_right,
//                                 size: 20,
//                               ),
//                               onPressed: channelState.toggleNameVisibility,
//                               padding: EdgeInsets.zero,
//                               constraints: const BoxConstraints(),
//                             ),
//                             if (showNames)
//                               const Text(
//                                 'Channels',
//                                 style: TextStyle(
//                                   fontWeight: FontWeight.bold,
//                                   fontSize: 14,
//                                 ),
//                               ),
//                           ],
//                         ),
//                       ),
//                       const Divider(height: 1),
//                       Expanded(
//                         child: ChannelList(
//                           channels: channels,
//                           onChannelSelected: () {
//                             _docScreenKey.currentState
//                                 ?.loadDocumentsForChannel();
//                           },
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//                 docColumn: DocScreen(key: _docScreenKey),
//                 workareaColumn: const WorkareaScreen(),
//               ),
//     );
//   }
// }
// import 'package:flutter/material.dart';
// import 'package:signals/signals_flutter.dart';
// import 'package:xdocapp/presentation/screens/user_screen/user_screen.dart';
// import '../../services/channel_service.dart';
// import '../../services/signal_state/channel_state.dart';
// import '../../widgets/responsive_layout.dart';
// import '../docs/doc_screen.dart';
// import '../work_area/workarea_screen.dart';
// import 'channel_list.dart';
// // import 'user_screen.dart';

// class ChannelScreen extends StatefulWidget {
//   const ChannelScreen({super.key});

//   @override
//   State<ChannelScreen> createState() => _ChannelScreenState();
// }

// class _ChannelScreenState extends State<ChannelScreen> {
//   final GlobalKey<DocScreenState> _docScreenKey = GlobalKey();
//   final TextEditingController _channelNameController = TextEditingController();
//   String userName = "John Doe"; // Replace with actual username

//   @override
//   void initState() {
//     super.initState();
//     _loadChannels();
//   }

//   @override
//   void dispose() {
//     _channelNameController.dispose();
//     super.dispose();
//   }

//   Future<void> _loadChannels() async {
//     await channelService.fetchChannels();
//     if (mounted &&
//         channelService.error.value == null &&
//         channelService.channels.value.isNotEmpty) {
//       channelState.selectChannelName(channelService.channels.value.first.name);
//       _docScreenKey.currentState?.loadDocumentsForChannel();
//     }
//   }

//   void _navigateToUserProfile() {
//     Navigator.push(
//       context,
//       MaterialPageRoute(builder: (context) => const UserScreen()),
//     );
//   }

//   void _showCreateChannelDialog() {
//     showDialog(
//       context: context,
//       builder: (context) => AlertDialog(
//         title: const Text('Create New Channel'),
//         content: TextField(
//           controller: _channelNameController,
//           decoration: const InputDecoration(
//             hintText: 'Enter channel name',
//             border: OutlineInputBorder(),
//           ),
//         ),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(context),
//             child: const Text('Close'),
//           ),
//           ElevatedButton(
//             onPressed: () async {
//               if (_channelNameController.text.trim().isNotEmpty) {
//                 await channelService.createChannel(
//                   _channelNameController.text.trim(),
//                 );
//                 if (mounted) {
//                   Navigator.pop(context);
//                   _channelNameController.clear();
//                   await _loadChannels();
//                 }
//               }
//             },
//             child: const Text('Create'),
//           ),
//         ],
//       ),
//     );
//   }

//   String _getUserInitials(String name) {
//     if (name.isEmpty) return 'US';
//     final parts = name.split(' ');
//     if (parts.length == 1) return parts[0].substring(0, 2).toUpperCase();
//     return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
//   }

//   @override
//   Widget build(BuildContext context) {
//     final showNames = channelState.showChannelNames.watch(context);
//     final isLoading = channelService.isLoading.watch(context);
//     final error = channelService.error.watch(context);
//     final channels = channelService.channels.watch(context);

//     return Scaffold(
//       body: isLoading
//           ? const Center(child: CircularProgressIndicator())
//           : error != null
//               ? Center(child: Text('Error: $error'))
//               : ResponsiveLayout(
//                   channelColumn: Container(
//                     width: showNames ? 240 : 72,
//                     decoration: BoxDecoration(
//                       border: Border(
//                         right: BorderSide(color: Colors.grey.shade300),
//                       ),
//                     ),
//                     child: Column(
//                       children: [
//                         // Top section with user avatar and name
//                         SizedBox(
//                           height: 56,
//                           child: Row(
//                             children: [
//                               Padding(
//                                 padding: const EdgeInsets.only(left: 12),
//                                 child: GestureDetector(
//                                   onTap: _navigateToUserProfile,
//                                   child: CircleAvatar(
//                                     radius: 16,
//                                     child: Text(
//                                       _getUserInitials(userName),
//                                       style: const TextStyle(fontSize: 12),
//                                     ),
//                                   ),
//                                 ),
//                               ),
//                               if (showNames)
//                                 Padding(
//                                   padding: const EdgeInsets.only(left: 8),
//                                   child: Text(userName),
//                                 ),
//                               const Spacer(),
//                             ],
//                           ),
//                         ),
//                         // Channels header with arrow first, then text
//                         SizedBox(
//                           height: 40,
//                           child: Row(
//                             children: [
//                               IconButton(
//                                 icon: Icon(
//                                   showNames
//                                       ? Icons.keyboard_arrow_left
//                                       : Icons.keyboard_arrow_right,
//                                   size: 20,
//                                 ),
//                                 onPressed: channelState.toggleNameVisibility,
//                                 padding: EdgeInsets.zero,
//                                 constraints: const BoxConstraints(),
//                               ),
//                               if (showNames)
//                                 const Text(
//                                   'Channels',
//                                   style: TextStyle(
//                                     fontWeight: FontWeight.bold,
//                                     fontSize: 14,
//                                   ),
//                                 ),
//                             ],
//                           ),
//                         ),
//                         const Divider(height: 1),
//                         Expanded(
//                           child: ChannelList(
//                             channels: channels,
//                             onChannelSelected: () {
//                               _docScreenKey.currentState
//                                   ?.loadDocumentsForChannel();
//                             },
//                           ),
//                         ),
//                         // Bottom section with add channel button
//                         Padding(
//                           padding: const EdgeInsets.all(8.0),
//                           child: Align(
//                             alignment: Alignment.centerLeft,
//                             child: IconButton(
//                               icon: const CircleAvatar(
//                                 radius: 16,
//                                 backgroundColor: Colors.blue,
//                                 child: Icon(
//                                   Icons.add,
//                                   size: 16,
//                                   color: Colors.white,
//                                 ),
//                               ),
//                               onPressed: _showCreateChannelDialog,
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                   docColumn: DocScreen(key: _docScreenKey),
//                   workareaColumn: const WorkareaScreen(),
//                 ),
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:signals/signals_flutter.dart';
import 'package:xdocapp/presentation/screens/user_screen/user_screen.dart';
import '../../services/channel_service.dart';
import '../../services/signal_state/channel_state.dart';
import '../../widgets/responsive_layout.dart';
import '../docs/doc_screen.dart';
import '../work_area/workarea_screen.dart';
import 'channel_list.dart';

class ChannelScreen extends StatefulWidget {
  const ChannelScreen({super.key});

  @override
  State<ChannelScreen> createState() => _ChannelScreenState();
}

class _ChannelScreenState extends State<ChannelScreen> {
  final GlobalKey<DocScreenState> _docScreenKey = GlobalKey();
  final TextEditingController _channelNameController = TextEditingController();
  final String userName = "John Doe";
  bool _isHovering = false;

  @override
  void initState() {
    super.initState();
    _loadChannels();
  }

  @override
  void dispose() {
    _channelNameController.dispose();
    super.dispose();
  }

  Future<void> _loadChannels() async {
    await channelService.fetchChannels();
    if (mounted &&
        channelService.error.value == null &&
        channelService.channels.value.isNotEmpty) {
      channelState.selectChannelName(channelService.channels.value.first.name);
      _docScreenKey.currentState?.loadDocumentsForChannel();
    }
  }

  void _navigateToUserProfile() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const UserScreen()),
    );
  }

  void _showCreateChannelDialog() {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Create New Channel'),
            content: TextField(
              controller: _channelNameController,
              decoration: const InputDecoration(
                hintText: 'Enter channel name',
                border: OutlineInputBorder(),
              ),
              autofocus: true,
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Close'),
              ),
              ElevatedButton(
                onPressed: () async {
                  final channelName = _channelNameController.text.trim();
                  if (channelName.isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Please enter a channel name'),
                      ),
                    );
                    return;
                  }

                  try {
                    await channelService.createChannel(channelName);
                    if (mounted) {
                      Navigator.pop(context);
                      _channelNameController.clear();
                      await _loadChannels();
                      final newChannel = channelService.channels.value.last;
                      channelState.selectChannelName(newChannel.name);
                      _docScreenKey.currentState?.loadDocumentsForChannel();
                    }
                  } catch (e) {
                    if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Failed to create channel: $e')),
                      );
                    }
                  }
                },
                child: const Text('Create'),
              ),
            ],
          ),
    );
  }

  String _getUserInitials(String name) {
    if (name.isEmpty) return 'US';
    final parts = name.split(' ');
    if (parts.length == 1) return parts[0].substring(0, 2).toUpperCase();
    return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    final showNames = channelState.showChannelNames.watch(context);
    final isLoading = channelService.isLoading.watch(context);
    final error = channelService.error.watch(context);
    final channels = channelService.channels.watch(context);

    return Scaffold(
      body:
          isLoading
              ? const Center(child: CircularProgressIndicator())
              : error != null
              ? Center(child: Text('Error: $error'))
              : ResponsiveLayout(
                channelColumn: Container(
                  width: showNames ? 240 : 72,
                  decoration: BoxDecoration(
                    border: Border(
                      right: BorderSide(color: Colors.grey.shade300),
                    ),
                  ),
                  child: Column(
                    children: [
                      SizedBox(
                        height: 56,
                        child: Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 12),
                              child: GestureDetector(
                                onTap: _navigateToUserProfile,
                                child: CircleAvatar(
                                  radius: 16,
                                  child: Text(
                                    _getUserInitials(userName),
                                    style: const TextStyle(fontSize: 12),
                                  ),
                                ),
                              ),
                            ),
                            if (showNames)
                              Padding(
                                padding: const EdgeInsets.only(left: 8),
                                child: Text(userName),
                              ),
                            const Spacer(),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 40,
                        child: MouseRegion(
                          onEnter: (_) => setState(() => _isHovering = true),
                          onExit: (_) => setState(() => _isHovering = false),
                          child: Row(
                            children: [
                              IconButton(
                                icon: Icon(
                                  showNames
                                      ? Icons.keyboard_arrow_left
                                      : Icons.keyboard_arrow_right,
                                  size: 20,
                                ),
                                onPressed: channelState.toggleNameVisibility,
                                padding: EdgeInsets.zero,
                                constraints: const BoxConstraints(),
                                tooltip:
                                    _isHovering
                                        ? (showNames ? 'Collapse' : 'Expand')
                                        : null,
                              ),
                              if (showNames)
                                const Text(
                                  'Channels',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                      const Divider(height: 1),
                      Expanded(
                        child: ChannelList(
                          channels: channels,
                          showNames: showNames,
                          onChannelSelected: () {
                            _docScreenKey.currentState
                                ?.loadDocumentsForChannel();
                          },
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Tooltip(
                            message: 'Create new channel',
                            child: IconButton(
                              icon: const CircleAvatar(
                                radius: 16,
                                backgroundColor: Colors.blue,
                                child: Icon(
                                  Icons.add,
                                  size: 16,
                                  color: Colors.white,
                                ),
                              ),
                              onPressed: _showCreateChannelDialog,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                docColumn: DocScreen(key: _docScreenKey),
                workareaColumn: const WorkareaScreen(),
              ),
    );
  }
}
